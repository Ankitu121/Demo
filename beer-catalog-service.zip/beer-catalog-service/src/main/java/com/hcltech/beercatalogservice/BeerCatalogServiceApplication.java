package com.hcltech.beercatalogservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeerCatalogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeerCatalogServiceApplication.class, args);
	}

}

